interface OnReceived {
    void onDisconnect(Session session);
}