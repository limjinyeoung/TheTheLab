interface SessionListener {
    void onAddWord(String word);

    void onRemoveWord(String word);
}
