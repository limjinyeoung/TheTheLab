interface SessionListener {
    void onDisconnect(Session session);
}
