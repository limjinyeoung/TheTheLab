
public interface ExampleObjectInterface {

    // x, y
    // pApplet

    public void update();
    public void render();
}
