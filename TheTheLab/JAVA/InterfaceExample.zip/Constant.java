public class Constant {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int BAR_HEIGHT = 50;
}
