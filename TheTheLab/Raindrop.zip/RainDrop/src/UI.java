import processing.core.PApplet;

public class UI extends View {
    private int life = 5;

    UI(PApplet pApplet) {
        super(pApplet);

        position.x = Constants.WIDTH / 2 - 95;
        position.y = Constants.HEIGHT - 55;
        size.x = Constants.INPUT_WIDTH;
        size.y = Constants.INPUT_HEIGHT;

        SpriteManager.putImage(pApplet, Constants.BACKGROUND, "./images/sansungbi.png");
        SpriteManager.putImage(pApplet, Constants.LIFE, "./images/life.png");
        SpriteManager.putImage(pApplet, Constants.TEXTBOX, "./images/textbox.png");
        SpriteManager.putImage(pApplet, Constants.GAMEOVER, "./images/gameover.png");
    }

    @Override
    public void onUpdate() {

    }

    @Override
    public void render() {
        //배경 이미지
        pApplet.image(SpriteManager.getImage(Constants.BACKGROUND), 0, 0, Constants.WIDTH, Constants.HEIGHT);
        //life 이미지
        for (int i = 0; i < life; i++){
            pApplet.fill(255, 0, 0);
            pApplet.image(SpriteManager.getImage(Constants.LIFE), 10 + (i * 20), 10, 20, 20);
        }
        //텍스트박스 이미지
        pApplet.image(SpriteManager.getImage(Constants.TEXTBOX), position.x, position.y, size.x, size.y);
    }

    @Override
    public void onCollision(View view) {

    }

    @Override
    public boolean isCollision(float mouseX, float mouseY) {
        return false;
    }

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }
}
