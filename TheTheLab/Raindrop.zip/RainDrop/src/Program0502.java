import processing.core.PApplet;
import java.util.ArrayList;
import java.util.List;

public class Program0502 extends PApplet {
    public static List<Text> words = new ArrayList<>();
    private UI ui;
    private static WordList wordList;
    private List<Character> answer = new ArrayList<>();
    private StringBuilder builder = new StringBuilder();

    public static void main(String[] args) {
        Program0502.main("Program0502");
        wordList = new WordList();
        wordList.start();
    }


    public void settings() {
        size(Constants.WIDTH, Constants.HEIGHT);
    }

    public void setup() {
        ui = new UI(this);
        wordList.setPApplet(this);
    }

    public void draw() {
        background(255);

        ui.render();

        if (ui.getLife() != 0) {
            for (int i = 0; i < words.size(); i++) {
                words.get(i).update();
                words.get(i).render();
                if (!words.get(i).getVisible()) {
                    ui.setLife(ui.getLife() - 1);
                    words.remove(i);
                }
            }

            for (int i = 0; i < answer.size(); i++) {
                fill(0);
                textSize(20);
                text(answer.get(i), ui.getPosition().x + (i * 10) + 30,
                        ui.getPosition().y + 25);
            }
        } else {
            image(SpriteManager.getImage(Constants.GAMEOVER),
                    0,0, Constants.WIDTH, Constants.HEIGHT);
        }


    }

    public void keyPressed() {
        if (key >= 'a' && key <= 'z') {
            answer.add(key);
        } else if (keyCode == 8) {
            if (answer.size() != 0)
                answer.remove(answer.size() - 1);
        } else if (key == ' ') {

            for (Character anAnswer : answer)
                builder.append(anAnswer);

            for (int i = 0; i < words.size(); i++) {
                if (builder.toString().equals(words.get(i).getString())
                        && words.get(i).getVisible()) {
                    words.get(i).deleteState = true;
                    break;
                }
            }
            builder.delete(0, builder.length());
            answer.clear();
        }
    }

    public void keyReleased(){
    }
}
