import processing.core.PApplet;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

//wordList : 클라이언트 관리
public class WordList extends Thread {

    private PApplet pApplet;
    public void setPApplet(PApplet pApplet){
        this.pApplet = pApplet;
    }

    public void run() {
        Socket socket = new Socket();
        //InetSocketAddress endpoint = new InetSocketAddress("192.168.11.198", 3000);
        InetSocketAddress endpoint = new InetSocketAddress("localhost", 3000);
        try {
            socket.connect(endpoint);
        } catch (IOException e) {
            e.printStackTrace();
        }

        OutputStream os = null;
        try {
            os = socket.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        InputStream is = null;
        try {
            is = socket.getInputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }

        byte[] buf = new byte[128];
        int len = 0;
        String s;       //!또는. 포함 단어
        String string;  //!제외한 단어

        while (len != -1) {
            try {
                len = is.read(buf);
                s = new String(buf, 0, len);

                if(s.charAt(0) == '!'){
                    string = s.substring(1, s.length());
                    Program0502.words.add(new Text(string, pApplet));
                }
                else if(s.charAt(0) == '.'){
                    string = s.substring(1, s.length());
                    for (int i = 0; i < Program0502.words.size(); i++){
                        if(string.equals(Program0502.words.get(i).getString())){
                            System.out.println(Program0502.words.get(i).getString());
                            Program0502.words.remove(i);
                            break;
                        }
                    }


                }

                for (int i = 0; i < Program0502.words.size(); i++){
                    if(Program0502.words.get(i).deleteState){
                        os.write(Program0502.words.get(i).getString().getBytes());
                        break;
                    }
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
