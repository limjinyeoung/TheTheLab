import processing.core.PApplet;

public class Text extends View {

    private boolean visible = true;
    private String string;
    public boolean deleteState;

    Text(String s, PApplet pApplet) {
        super(pApplet);
        position.x = (float)Math.random()* (Constants.WIDTH - 200);
        position.y = 0;
        string = s;
        deleteState = false;
        this.pApplet = pApplet;
    }

    @Override
    public void onUpdate() {

    }

    public void update() {
        position.y += 1;
        if (isCollision())
            visible = false;
    }

    public void render() {
            if (visible) {
                pApplet.fill(0);
                pApplet.textSize(20);
                pApplet.text(string, position.x, position.y);
            }
    }

    @Override
    public void onCollision(View view) {

    }

    @Override
    public boolean isCollision(float mouseX, float mouseY) {
        return false;
    }


    public boolean isCollision() {
        return position.y > Constants.HEIGHT - 120;
    }

    public String getString(){
        return string;
    }

    public boolean getVisible(){
        return visible;
    }
}
