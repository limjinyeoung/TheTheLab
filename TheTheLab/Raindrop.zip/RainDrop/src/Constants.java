public class Constants {

    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;

    public static final int INPUT_WIDTH = 190;
    public static final int INPUT_HEIGHT = 30;

    public static final int BACKGROUND = 1;
    public static final int LIFE = 2;
    public static final int TEXTBOX = 3;
    public static final int GAMEOVER = 4;


}
