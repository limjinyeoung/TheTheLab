import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Thread.sleep;

//1초마다 !붙은 단어 생성하고 클라이언트에 알림.
class Connection implements Runnable {

    private String[] string = {
            "string", "processing", "blocksize", "thread",
            "ticket", "blackhole", "networking"
    };

    private Socket socket;

    Connection(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        InputStream is = null;
        OutputStream os = null;

        try {
            os = socket.getOutputStream();

        } catch (IOException e) {
            e.printStackTrace();
        }

        StringBuilder creatingWord = new StringBuilder();

        try {
            while (true) {
                int i = (int) (Math.random() * 7);
                try {
                    sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                creatingWord.append('!');
                creatingWord.append(string[i]);
                byte[] send = creatingWord.toString().getBytes();
                os.write(send, 0, send.length);
                creatingWord.delete(0, creatingWord.length());
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

//
class Connection1 implements Runnable {
    private String[] string = {
            "string", "processing", "blocksize", "thread",
            "ticket", "blackhole", "networking"
    };

    private Socket socket;

    private int len;

    Connection1(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {

        InputStream is = null;
        OutputStream os = null;

        try {
            is = socket.getInputStream();
            os = socket.getOutputStream();

        } catch (IOException e) {
            e.printStackTrace();
        }

        StringBuilder deletingWord = new StringBuilder();
        byte[] buf = new byte[128];

        try {
            while (true) {
                if ((len = is.read(buf)) > 1) {
                    deletingWord.append('.');
                    String s = new String(buf, 0, len);
                    deletingWord.append(s);
                    byte[] send = deletingWord.toString().getBytes();
                    os.write(send, 0, send.length);
                    deletingWord.delete(0, deletingWord.length());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


public class Server {
    public static void main(String[] args) throws Exception {

        ServerSocket serverSocket = new ServerSocket(3000);

        while (true) {
            Socket socket = serverSocket.accept();
            System.out.println(socket.getRemoteSocketAddress());

            Thread fooThread = new Thread(new Connection(socket));
            Thread fooThread1 = new Thread(new Connection1(socket));
            fooThread.start();
            fooThread1.start();
        }
    }
}