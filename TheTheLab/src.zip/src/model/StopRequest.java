package model;

public class StopRequest {
    private final String type;
    public StopRequest() {
        this.type = "Stop";
    }
}
