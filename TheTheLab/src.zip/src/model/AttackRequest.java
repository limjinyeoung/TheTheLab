package model;

public class AttackRequest {
    private final String type;
    public AttackRequest() {
        this.type = "Attack";
    }
}
